#-------Set the environment variables"
export MY_CLUSTER=rke4yong1
export MY_REGION=ap-southeast-1         #Customize your favorite region
export MY_ZONE=ap-southeast-1a          #Customize your favorite zone
export MY_BUCKET=k10bucket4yong1-sg     #Customize your favorite bucket
export MY_OBJECT_STORAGE_PROFILE=myoss1 #Customize your favorite profile name
